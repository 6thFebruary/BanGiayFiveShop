/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

import Model.ChiTietGiay;
import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public interface SanPhamChiTietImpl {
    ArrayList<ChiTietGiay> getAllChiTietGiay();
    ArrayList<ChiTietGiay>getChiTietSanPham();
}
